ARTIFY GOURAB — PERSONALIZED WEBSITE STARTER

Included:
- index.html: responsive portfolio website
- assets/artify-gourab-logo.png: supplied logo
- assets/doraemon-artwork.jpg: supplied drawing

Privacy:
This public-ready starter does not display the artist's age, town, or email address. Keep personal contact details private and have a parent/guardian review the site before publishing.

Preview:
Extract the ZIP and open index.html in Chrome.

Publishing:
This static site can be published using a free hosting service. Ask a parent/guardian to help with account setup and public publishing. GitHub Pages sites are public; do not upload private information.
