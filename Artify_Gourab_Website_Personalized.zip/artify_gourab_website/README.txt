ARTIFY GOURAB — PERSONALIZED WEBSITE STARTER

Included:
- index.html: responsive portfolio website
- assets/artify-gourab-logo.png: your supplied logo
- assets/doraemon-artwork.jpg: your supplied drawing

Preview:
Extract the ZIP and open index.html in Chrome.

The site currently links to your YouTube channel and uses your uploaded logo and first artwork. The remaining gallery slots are placeholders.

Publishing:
You can publish this static site on a free hosting service. Account setup and public publishing should be done with a parent/guardian's help. A custom domain may cost extra.
