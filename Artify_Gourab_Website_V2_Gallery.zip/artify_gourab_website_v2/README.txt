ARTIFY GOURAB WEBSITE — VERSION 2

Upload index.html and the complete assets folder to the root of your GitHub repository. Keep the assets folder name unchanged. Then GitHub Pages will publish the updated portfolio.
